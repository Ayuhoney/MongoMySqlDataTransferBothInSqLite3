// // Import required modules
// const sqlite3 = require('sqlite3').verbose();
// const { MongoClient } = require('mongodb');
// const mysql = require('mysql2/promise');

// // MySQL configuration
// const mysqlConfig = {
//     host: 'demo-coucal-db.cba0oi2ek1d8.ap-south-1.rds.amazonaws.com',
//     user: 'ayush',
//     password: 'ayush',
//     database: 'demo_coucal'
// };

// // MongoDB configuration
// const mongoUrl = 'mongodb://ayush:ayush@demo-coucal-documentdb-cluster.cluster-cba0oi2ek1d8.ap-south-1.docdb.amazonaws.com:27017/?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false';
// const mongoDbName = 'demo-coucal';
// const mongoCollectionName = 'Resume_Details';

// // Function to fetch data from MongoDB
// async function fetchDataFromMongoDB() {
//     try {
//         const client = new MongoClient(mongoUrl, { useUnifiedTopology: true });
//         await client.connect();
//         console.log('Connected to MongoDB');
//         const db = client.db(mongoDbName);
//         const collection = db.collection(mongoCollectionName);
//         const data = await collection.find({}).toArray();
//         await client.close();
//         return data;
//     } catch (error) {
//         console.error('Error fetching data from MongoDB:', error);
//         throw error;
//     }
// }

// // Function to fetch data from MySQL
// async function fetchDataFromMySQL() {
//     try {
//         const connection = await mysql.createConnection(mysqlConfig);
//         console.log('Connected to MySQL');

//         const [rows] = await connection.execute('SELECT * FROM client_table');
//         await connection.end();

//         return rows;
//     } catch (error) {
//         console.error('Error fetching data from MySQL:', error);
//         throw error;
//     }
// }

// // Function to insert data into SQLite
// // Function to insert data into SQLite
// async function insertDataIntoSQLite(data) {
//     try {
//         const db = new sqlite3.Database('data.db');
//         console.log('Connected to SQLite');
        
//         db.serialize(() => {
//             db.run('CREATE TABLE IF NOT EXISTS user (id TEXT, name TEXT)');
//             const stmt = db.prepare('INSERT INTO user (id, name) VALUES (?, ?)');

//             data.forEach((row) => {
//                 console.log('Inserting data:', row); // Log the data before inserting
                
//                 stmt.run(row.id || '', row.name || ''); // Ensure that undefined values are converted to empty strings
//             });

//             stmt.finalize();
//         });

//         db.close();
//     } catch (error) {
//         console.error('Error inserting data into SQLite:', error);
//         throw error;
//     }
// }


// async function main() {
//     try {
//         const mongoData = await fetchDataFromMongoDB();
//         console.log('MongoDB Data:', mongoData);
        
//         const mysqlData = await fetchDataFromMySQL();
//         console.log('MySQL Data:', mysqlData);
        
//         const combinedData = [...mongoData, ...mysqlData];

//         await insertDataIntoSQLite(combinedData);
//     } catch (error) {
//         console.error('Error:', error);
//     }
// }
// main();

//-----------------------------------------------------------------------------------------------------------------------------------------------------------
// const sqlite3 = require('sqlite3').verbose();
// const { MongoClient,ObjectId } = require('mongodb');
// const mysql = require('mysql2/promise');

// // MySQL configuration
// const mysqlConfig = {
//     host: 'demo-coucal-db.cba0oi2ek1d8.ap-south-1.rds.amazonaws.com',
//     user: 'ayush',
//     password: 'ayush',
//     database: 'demo_coucal'
// };

// // MongoDB configuration
// const mongoUrl = 'mongodb://ayush:ayush@demo-coucal-documentdb-cluster.cluster-cba0oi2ek1d8.ap-south-1.docdb.amazonaws.com:27017/?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false';
// const mongoDbName = 'demo-coucal';
// const mongoCollectionName = 'Resume_Details';

// // Function to fetch data from MongoDB
// async function fetchDataFromMongoDB() {
//     try {
//         const client = new MongoClient(mongoUrl, { useUnifiedTopology: true });
//         await client.connect();
//         console.log('Connected to MongoDB');
//         const db = client.db(mongoDbName);
//         const collection = db.collection(mongoCollectionName);
//         const data = await collection.find({}).toArray();
//         await client.close();
//         return data;
//     } catch (error) {
//         console.error('Error fetching data from MongoDB:', error);
//         throw error;
//     }
// }

// // Function to fetch data from MySQL
// async function fetchDataFromMySQL() {
//     try {
//         const connection = await mysql.createConnection(mysqlConfig);
//         console.log('Connected to MySQL');

//         const [rows] = await connection.execute('SELECT * FROM client_table');
//         await connection.end();

//         return rows;
//     } catch (error) {
//         console.error('Error fetching data from MySQL:', error);
//         throw error;
//     }
// }


// // Function to insert MySQL data into SQLite
// async function insertMySQLDataIntoSQLite(data) {
//     try {
//         const db = new sqlite3.Database('data.db');
//         console.log('Connected to SQLite');

//         db.serialize(() => {
//             // Create the table if it doesn't exist
//             db.run(`CREATE TABLE IF NOT EXISTS mysql_data (
//                 address TEXT,
//                 client_id INTEGER,
//                 creator_email_id TEXT,
//                 creation_date TEXT,
//                 client_website TEXT,
//                 client_name TEXT,
//                 balance REAL,
//                 job_count TEXT,
//                 plan TEXT
//             )`);

//             const stmt = db.prepare(`INSERT INTO mysql_data (
//                 address,
//                 client_id,
//                 creator_email_id,
//                 creation_date,
//                 client_website,
//                 client_name,
//                 balance,
//                 job_count,
//                 plan
//             ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);

//             data.forEach((row) => {
//                 stmt.run(
//                     row.address || '',
//                     row.client_id || 0,
//                     row.creator_email_id || '',
//                     row.creation_date ? new Date(row.creation_date).toISOString() : '',
//                     row.client_website || '',
//                     row.client_name || '',
//                     row.balance || 0,
//                     row.job_count || '',
//                     row.plan || ''
//                 );
//             });
//             stmt.finalize();
//         });

//         db.close();
//         console.log('MySQL data inserted into SQLite');
//     } catch (error) {
//         console.error('Error inserting MySQL data into SQLite:', error);
//         throw error;
//     }
// }


// async function insertMongoDBDataIntoSQLite(data) {
//     try {
//         const db = new sqlite3.Database('data.db');
//         console.log('Connected to SQLite');

//         // Delete the existing table
//         await new Promise((resolve, reject) => {
//             db.run(`DROP TABLE IF EXISTS mongodb_data`, (err) => {
//                 if (err) {
//                     console.error('Error deleting mongodb_data table:', err);
//                     reject(err);
//                 } else {
//                     console.log('mongodb_data table deleted');
//                     resolve();
//                 }
//             });
//         });

//         // Create the table
//         await new Promise((resolve, reject) => {
//             db.run(`CREATE TABLE IF NOT EXISTS mongodb_data (
//                 _id TEXT PRIMARY KEY,
//                 Name TEXT,
//                 Current_Location TEXT,
//                 Phone_Number TEXT,
//                 Email_ID TEXT,
//                 Profile_Link TEXT,
//                 Work_Experience REAL,
//                 Skills TEXT,
//                 Qualification TEXT,
//                 Projects TEXT,
//                 client_id TEXT,
//                 job_id TEXT,
//                 resume_id TEXT,
//                 nearby TEXT,
//                 screening_call_date TEXT,
//                 screening_call_status TEXT,
//                 screening_call_day TEXT,
//                 screening_call_start_time TEXT,
//                 screening_call_end_time TEXT,
//                 ranklocation TEXT,
//                 candidate_score INTEGER,
//                 matching_skills TEXT,
//                 matching_work_experience TEXT
//             )`, (err) => {
//                 if (err) {
//                     console.error('Error creating mongodb_data table:', err);
//                     reject(err);
//                 } else {
//                     console.log('mongodb_data table created');
//                     resolve();
//                 }
//             });
//         });

//         // Prepare the insert statement
//         const stmt = db.prepare(`INSERT INTO mongodb_data (
//             _id,
//             Name,
//             Current_Location,
//             Phone_Number,
//             Email_ID,
//             Profile_Link,
//             Work_Experience,
//             Skills,
//             Qualification,
//             Projects,
//             client_id,
//             job_id,
//             resume_id,
//             nearby,
//             screening_call_date,
//             screening_call_status,
//             screening_call_day,
//             screening_call_start_time,
//             screening_call_end_time,
//             ranklocation,
//             candidate_score,
//             matching_skills,
//             matching_work_experience
//         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

//         // Insert data into the table
//         data.forEach((doc) => {
//             const idString = doc._id instanceof ObjectId ? doc._id.toString() : doc._id;
//             stmt.run(
//                 idString,  // Ensure _id is converted to string
//                 doc.Name || '',
//                 Array.isArray(doc.Current_Location) ? doc.Current_Location.join(', ') : (doc.Current_Location || ''),
//                 Array.isArray(doc.Phone_Number) ? doc.Phone_Number.join(', ') : (doc.Phone_Number || ''),
//                 Array.isArray(doc.Email_ID) ? doc.Email_ID.join(', ') : (doc.Email_ID || ''),
//                 doc.Profile_Link || '',
//                 doc.Work_Experience || 0,
//                 Array.isArray(doc.Skills) ? doc.Skills.join(', ') : (doc.Skills || ''),
//                 Array.isArray(doc.Qualification) ? doc.Qualification.join(', ') : (doc.Qualification || ''),
//                 Array.isArray(doc.Projects) ? doc.Projects.join(', ') : (doc.Projects || ''),
//                 doc.client_id || '',
//                 doc.job_id || '',
//                 doc.resume_id || '',
//                 doc.nearby.toString(),
//                 doc.screening_call_date || '',
//                 doc.screening_call_status || '',
//                 doc.screening_call_day || '',
//                 doc.screening_call_start_time || '',
//                 doc.screening_call_end_time || '',
//                 doc.ranklocation || '',
//                 doc.candidate_score || 0,
//                 doc.matching_skills || '',
//                 doc.matching_work_experience || ''
//             );
//         });

//         // Finalize the statement
//         stmt.finalize();

//         console.log('Data inserted into mongodb_data table');

//         // Close the database connection
//         db.close();
//     } catch (error) {
//         console.error('Error inserting MongoDB data into SQLite:', error);
//         throw error;
//     }
// }

// //Function to fetch and log SQLite data
// function fetchAndLogSQLiteData() {
//     const db = new sqlite3.Database('data.db');
//     db.serialize(() => {
//         db.all('SELECT * FROM mongodb_data', (err, rows) => {
//             if (err) {
//                 console.error('Error fetching data from mongodb_data in SQLite:', err);
//                 return;
//             }
//             console.log('MongoDB Data in SQLite:', rows);
//         });

//         db.all('SELECT * FROM mysql_data', (err, rows) => {
//             if (err) {
//                 console.error('Error fetching data from mysql_data in SQLite:', err);
//                 return;
//             }
//             console.log('MySQL Data in SQLite:', rows);
//         });
//     });
//     db.close();
// }


// // Main function to fetch data and insert into SQLite
// async function main() {
//     try {
//         const mongoData = await fetchDataFromMongoDB();
//         const mysqlData = await fetchDataFromMySQL();
        
//         await insertMongoDBDataIntoSQLite(mongoData);
//         await insertMySQLDataIntoSQLite(mysqlData);

//         // Fetch and log SQLite data after insertion
//         fetchAndLogSQLiteData();
//     } catch (error) {
//         console.error('Error:', error);
//     }
// }

// main();

//--------------------------------mongo-with-client-jobs---------------------------------------------------------------------------------------------

// const sqlite3 = require('sqlite3').verbose();
// const { MongoClient,ObjectId } = require('mongodb');
// const mysql = require('mysql2/promise');

// // MySQL configuration
// const mysqlConfig = {
//     host: 'demo-coucal-db.cba0oi2ek1d8.ap-south-1.rds.amazonaws.com',
//     user: 'ayush',
//     password: 'ayush',
//     database: 'demo_coucal'
// };

// // MongoDB configuration
// const mongoUrl = 'mongodb://ayush:ayush@demo-coucal-documentdb-cluster.cluster-cba0oi2ek1d8.ap-south-1.docdb.amazonaws.com:27017/?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false';
// const mongoDbName = 'demo-coucal';
// const mongoCollectionName = 'Resume_Details';

// // Function to fetch data from MongoDB
// async function fetchDataFromMongoDB() {
//     try {
//         const client = new MongoClient(mongoUrl, { useUnifiedTopology: true });
//         await client.connect();
//         console.log('Connected to MongoDB');
//         const db = client.db(mongoDbName);
//         const collection = db.collection(mongoCollectionName);
//         const data = await collection.find({}).toArray();
//         await client.close();
//         return data;
//     } catch (error) {
//         console.error('Error fetching data from MongoDB:', error);
//         throw error;
//     }
// }

// // Function to fetch data from MySQL
// async function fetchDataFromMySQL() {
//     try {
//         const connection = await mysql.createConnection(mysqlConfig);
//         console.log('Connected to MySQL');

//         const [rows] = await connection.execute('SELECT * FROM client_table');
//         await connection.end();

//         return rows;
//     } catch (error) {
//         console.error('Error fetching data from MySQL:', error);
//         throw error;
//     }
// }


// // Function to insert MySQL data into SQLite
// async function insertMySQLDataIntoSQLite(data) {
//     try {
//         const db = new sqlite3.Database('data.db');
//         console.log('Connected to SQLite');

//         db.serialize(() => {
//             // Create the table if it doesn't exist
//             db.run(`CREATE TABLE IF NOT EXISTS client_mysql_data (
//                 address TEXT,
//                 client_id INTEGER,
//                 creator_email_id TEXT,
//                 creation_date TEXT,
//                 client_website TEXT,
//                 client_name TEXT,
//                 balance REAL,
//                 job_count TEXT,
//                 plan TEXT
//             )`);

//             const stmt = db.prepare(`INSERT INTO client_mysql_data (
//                 address,
//                 client_id,
//                 creator_email_id,
//                 creation_date,
//                 client_website,
//                 client_name,
//                 balance,
//                 job_count,
//                 plan
//             ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);

//             data.forEach((row) => {
//                 stmt.run(
//                     row.address || '',
//                     row.client_id || 0,
//                     row.creator_email_id || '',
//                     row.creation_date ? new Date(row.creation_date).toISOString() : '',
//                     row.client_website || '',
//                     row.client_name || '',
//                     row.balance || 0,
//                     row.job_count || '',
//                     row.plan || ''
//                 );
//             });
//             stmt.finalize();
//         });

//         db.close();
//         console.log('MySQL data inserted into SQLite');
//     } catch (error) {
//         console.error('Error inserting MySQL data into SQLite:', error);
//         throw error;
//     }
// }


// async function insertMongoDBDataIntoSQLite(data) {
//     try {
//         const db = new sqlite3.Database('data.db');
//         console.log('Connected to SQLite');

//         // Delete the existing table
//         await new Promise((resolve, reject) => {
//             db.run(`DROP TABLE IF EXISTS mongodb_data`, (err) => {
//                 if (err) {
//                     console.error('Error deleting mongodb_data table:', err);
//                     reject(err);
//                 } else {
//                     console.log('mongodb_data table deleted');
//                     resolve();
//                 }
//             });
//         });

//         // Create the table
//         await new Promise((resolve, reject) => {
//             db.run(`CREATE TABLE IF NOT EXISTS mongodb_data (
//                 _id TEXT PRIMARY KEY,
//                 Name TEXT,
//                 Current_Location TEXT,
//                 Phone_Number TEXT,
//                 Email_ID TEXT,
//                 Profile_Link TEXT,
//                 Work_Experience REAL,
//                 Skills TEXT,
//                 Qualification TEXT,
//                 Projects TEXT,
//                 client_id TEXT,
//                 job_id TEXT,
//                 resume_id TEXT,
//                 nearby TEXT,
//                 screening_call_date TEXT,
//                 screening_call_status TEXT,
//                 screening_call_day TEXT,
//                 screening_call_start_time TEXT,
//                 screening_call_end_time TEXT,
//                 ranklocation TEXT,
//                 candidate_score INTEGER,
//                 matching_skills TEXT,
//                 matching_work_experience TEXT
//             )`, (err) => {
//                 if (err) {
//                     console.error('Error creating mongodb_data table:', err);
//                     reject(err);
//                 } else {
//                     console.log('mongodb_data table created');
//                     resolve();
//                 }
//             });
//         });

//         // Prepare the insert statement
//         const stmt = db.prepare(`INSERT INTO mongodb_data (
//             _id,
//             Name,
//             Current_Location,
//             Phone_Number,
//             Email_ID,
//             Profile_Link,
//             Work_Experience,
//             Skills,
//             Qualification,
//             Projects,
//             client_id,
//             job_id,
//             resume_id,
//             nearby,
//             screening_call_date,
//             screening_call_status,
//             screening_call_day,
//             screening_call_start_time,
//             screening_call_end_time,
//             ranklocation,
//             candidate_score,
//             matching_skills,
//             matching_work_experience
//         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

//         // Insert data into the table
//         data.forEach((doc) => {
//             const idString = doc._id instanceof ObjectId ? doc._id.toString() : doc._id;
//             stmt.run(
//                 idString,  // Ensure _id is converted to string
//                 doc.Name || '',
//                 Array.isArray(doc.Current_Location) ? doc.Current_Location.join(', ') : (doc.Current_Location || ''),
//                 Array.isArray(doc.Phone_Number) ? doc.Phone_Number.join(', ') : (doc.Phone_Number || ''),
//                 Array.isArray(doc.Email_ID) ? doc.Email_ID.join(', ') : (doc.Email_ID || ''),
//                 doc.Profile_Link || '',
//                 doc.Work_Experience || 0,
//                 Array.isArray(doc.Skills) ? doc.Skills.join(', ') : (doc.Skills || ''),
//                 Array.isArray(doc.Qualification) ? doc.Qualification.join(', ') : (doc.Qualification || ''),
//                 Array.isArray(doc.Projects) ? doc.Projects.join(', ') : (doc.Projects || ''),
//                 doc.client_id || '',
//                 doc.job_id || '',
//                 doc.resume_id || '',
//                 doc.nearby.toString(),
//                 doc.screening_call_date || '',
//                 doc.screening_call_status || '',
//                 doc.screening_call_day || '',
//                 doc.screening_call_start_time || '',
//                 doc.screening_call_end_time || '',
//                 doc.ranklocation || '',
//                 doc.candidate_score || 0,
//                 doc.matching_skills || '',
//                 doc.matching_work_experience || ''
//             );
//         });

//         // Finalize the statement
//         stmt.finalize();

//         console.log('Data inserted into mongodb_data table');

//         // Close the database connection
//         db.close();
//     } catch (error) {
//         console.error('Error inserting MongoDB data into SQLite:', error);
//         throw error;
//     }
// }

// //Function to fetch and log SQLite data
// function fetchAndLogSQLiteData() {
//     const db = new sqlite3.Database('data.db');
//     db.serialize(() => {
//         db.all('SELECT * FROM mongodb_data', (err, rows) => {
//             if (err) {
//                 console.error('Error fetching data from mongodb_data in SQLite:', err);
//                 return;
//             }
//             console.log('MongoDB Data in SQLite:', rows);
//         });

//         db.all('SELECT * FROM client_mysql_data', (err, rows) => {
//             if (err) {
//                 console.error('Error fetching data from client_mysql_data in SQLite:', err);
//                 return;
//             }
//             console.log('Client_MySQL Data in SQLite:', rows);
//         });
//     });
//     db.close();
// }


// // Main function to fetch data and insert into SQLite
// async function main() {
//     try {
//         const mongoData = await fetchDataFromMongoDB();
//         const mysqlData = await fetchDataFromMySQL();
        
//         await insertMongoDBDataIntoSQLite(mongoData);
//         await insertMySQLDataIntoSQLite(mysqlData);

//         // Fetch and log SQLite data after insertion
//         fetchAndLogSQLiteData();
//     } catch (error) {
//         console.error('Error:', error);
//     }
// }

// main();

//------------------------------------------------------------------------------------------------------------------

// const sqlite3 = require('sqlite3').verbose();
// const { MongoClient, ObjectId } = require('mongodb');
// const mysql = require('mysql2/promise');

// // MySQL configuration
// const mysqlConfig = {
//     host: 'demo-coucal-db.cba0oi2ek1d8.ap-south-1.rds.amazonaws.com',
//     user: 'ayush',
//     password: 'ayush',
//     database: 'demo_coucal'
// };

// // MongoDB configuration
// const mongoUrl = 'mongodb://ayush:ayush@demo-coucal-documentdb-cluster.cluster-cba0oi2ek1d8.ap-south-1.docdb.amazonaws.com:27017/?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false';
// const mongoDbName = 'demo-coucal';
// const mongoCollectionName = 'Resume_Details';

// // Function to fetch data from MongoDB
// async function fetchDataFromMongoDB() {
//     try {
//         const client = new MongoClient(mongoUrl, { useUnifiedTopology: true });
//         await client.connect();
//         console.log('Connected to MongoDB');
//         const db = client.db(mongoDbName);
//         const collection = db.collection(mongoCollectionName);
//         const data = await collection.find({}).toArray();
//         await client.close();
//         return data;
//     } catch (error) {
//         console.error('Error fetching data from MongoDB:', error);
//         throw error;
//     }
// }

// // Function to fetch data from MySQL
// async function fetchDataFromMySQL() {
//     try {
//         const connection = await mysql.createConnection(mysqlConfig);
//         console.log('Connected to MySQL');

//         // Fetch data from client_table
//         const [clientRows] = await connection.execute('SELECT * FROM client_table');
        
//         // Fetch data from jobs_table
//         const [jobsRows] = await connection.execute('SELECT * FROM jobs_table');

//         await connection.end();

//         return { clientRows, jobsRows };
//     } catch (error) {
//         console.error('Error fetching data from MySQL:', error);
//         throw error;
//     }
// }

// // Function to insert MySQL client data into SQLite
// async function insertClientDataIntoSQLite(data) {
//     try {
//         const db = new sqlite3.Database('data.db');
//         console.log('Connected to SQLite');

//         db.serialize(() => {
//             db.run(`CREATE TABLE IF NOT EXISTS client_mysql_data (
//                 address TEXT,
//                 client_id INTEGER,
//                 creator_email_id TEXT,
//                 creation_date TEXT,
//                 client_website TEXT,
//                 client_name TEXT,
//                 balance REAL,
//                 job_count TEXT,
//                 plan TEXT
//             )`);

//             const stmt = db.prepare(`INSERT INTO client_mysql_data (
//                 address,
//                 client_id,
//                 creator_email_id,
//                 creation_date,
//                 client_website,
//                 client_name,
//                 balance,
//                 job_count,
//                 plan
//             ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);

//             data.forEach((row) => {
//                 stmt.run(
//                     row.address || '',
//                     row.client_id || 0,
//                     row.creator_email_id || '',
//                     row.creation_date ? new Date(row.creation_date).toISOString() : '',
//                     row.client_website || '',
//                     row.client_name || '',
//                     row.balance || 0,
//                     row.job_count || '',
//                     row.plan || ''
//                 );
//             });
//             stmt.finalize();
//         });

//         db.close();
//         console.log('Client MySQL data inserted into SQLite');
//     } catch (error) {
//         console.error('Error inserting client MySQL data into SQLite:', error);
//         throw error;
//     }
// }

// // Function to insert MySQL jobs data into SQLite
// async function insertJobsDataIntoSQLite(data) {
//     try {
//         const db = new sqlite3.Database('data.db');
//         console.log('Connected to SQLite');

//         db.serialize(() => {
//             db.run(`CREATE TABLE IF NOT EXISTS jobs_mysql_data (
//                 job_id INTEGER,
//                 job_title TEXT,
//                 company_name TEXT,
//                 location TEXT,
//                 salary REAL,
//                 posting_date TEXT,
//                 job_description TEXT
//             )`);

//             const stmt = db.prepare(`INSERT INTO jobs_mysql_data (
//                 job_id,
//                 job_title,
//                 company_name,
//                 location,
//                 salary,
//                 posting_date,
//                 job_description
//             ) VALUES (?, ?, ?, ?, ?, ?, ?)`);

//             data.forEach((row) => {
//                 stmt.run(
//                     row.job_id || 0,
//                     row.job_title || '',
//                     row.company_name || '',
//                     row.location || '',
//                     row.salary || 0,
//                     row.posting_date ? new Date(row.posting_date).toISOString() : '',
//                     row.job_description || ''
//                 );
//             });
//             stmt.finalize();
//         });

//         db.close();
//         console.log('Jobs MySQL data inserted into SQLite');
//     } catch (error) {
//         console.error('Error inserting jobs MySQL data into SQLite:', error);
//         throw error;
//     }
// }

// // Function to insert MongoDB data into SQLite
// async function insertMongoDBDataIntoSQLite(data) {
//     try {
//         const db = new sqlite3.Database('data.db');
//         console.log('Connected to SQLite');

//         // Delete the existing table
//         await new Promise((resolve, reject) => {
//             db.run(`DROP TABLE IF EXISTS mongodb_data`, (err) => {
//                 if (err) {
//                     console.error('Error deleting mongodb_data table:', err);
//                     reject(err);
//                 } else {
//                     console.log('mongodb_data table deleted');
//                     resolve();
//                 }
//             });
//         });

//         // Create the table
//         await new Promise((resolve, reject) => {
//             db.run(`CREATE TABLE IF NOT EXISTS mongodb_data (
//                 _id TEXT PRIMARY KEY,
//                 Name TEXT,
//                 Current_Location TEXT,
//                 Phone_Number TEXT,
//                 Email_ID TEXT,
//                 Profile_Link TEXT,
//                 Work_Experience REAL,
//                 Skills TEXT,
//                 Qualification TEXT,
//                 Projects TEXT,
//                 client_id TEXT,
//                 job_id TEXT,
//                 resume_id TEXT,
//                 nearby TEXT,
//                 screening_call_date TEXT,
//                 screening_call_status TEXT,
//                 screening_call_day TEXT,
//                 screening_call_start_time TEXT,
//                 screening_call_end_time TEXT,
//                 ranklocation TEXT,
//                 candidate_score INTEGER,
//                 matching_skills TEXT,
//                 matching_work_experience TEXT
//             )`, (err) => {
//                 if (err) {
//                     console.error('Error creating mongodb_data table:', err);
//                     reject(err);
//                 } else {
//                     console.log('mongodb_data table created');
//                     resolve();
//                 }
//             });
//         });

//         // Prepare the insert statement
//         const stmt = db.prepare(`INSERT INTO mongodb_data (
//             _id,
//             Name,
//             Current_Location,
//             Phone_Number,
//             Email_ID,
//             Profile_Link,
//             Work_Experience,
//             Skills,
//             Qualification,
//             Projects,
//             client_id,
//             job_id,
//             resume_id,
//             nearby,
//             screening_call_date,
//             screening_call_status,
//             screening_call_day,
//             screening_call_start_time,
//             screening_call_end_time,
//             ranklocation,
//             candidate_score,
//             matching_skills,
//             matching_work_experience
//         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

//         // Insert data into the table
//         data.forEach((doc) => {
//             const idString = doc._id instanceof ObjectId ? doc._id.toString() : doc._id;
//             stmt.run(
//                 idString,  // Ensure _id is converted to string
//                 doc.Name || '',
//                 Array.isArray(doc.Current_Location) ? doc.Current_Location.join(', ') : (doc.Current_Location || ''),
//                 Array.isArray(doc.Phone_Number) ? doc.Phone_Number.join(', ') : (doc.Phone_Number || ''),
//                 Array.isArray(doc.Email_ID) ? doc.Email_ID.join(', ') : (doc.Email_ID || ''),
//                 doc.Profile_Link || '',
//                 doc.Work_Experience || 0,
//                 Array.isArray(doc.Skills) ? doc.Skills.join(', ') : (doc.Skills || ''),
//                 Array.isArray(doc.Qualification) ? doc.Qualification.join(', ') : (doc.Qualification || ''),
//                 Array.isArray(doc.Projects) ? doc.Projects.join(', ') : (doc.Projects || ''),
//                 doc.client_id || '',
//                 doc.job_id || '',
//                 doc.resume_id || '',
//                 doc.nearby.toString(),
//                 doc.screening_call_date || '',
//                 doc.screening_call_status || '',
//                 doc.screening_call_day || '',
//                 doc.screening_call_start_time || '',
//                 doc.screening_call_end_time || '',
//                 doc.ranklocation || '',
//                 doc.candidate_score || 0,
//                 doc.matching_skills || '',
//                 doc.matching_work_experience || ''
//             );
//         });

//         // Finalize the statement
//         stmt.finalize();

//         console.log('Data inserted into mongodb_data table');

//         // Close the database connection
//         db.close();
//     } catch (error) {
//         console.error('Error inserting MongoDB data into SQLite:', error);
//         throw error;
//     }
// }

// // Function to fetch and log SQLite data
// function fetchAndLogSQLiteData() {
//     const db = new sqlite3.Database('data.db');
//     db.serialize(() => {
//         db.all('SELECT * FROM mongodb_data', (err, rows) => {
//             if (err) {
//                 console.error('Error fetching data from mongodb_data in SQLite:', err);
//                 return;
//             }
//             console.log('MongoDB Data in SQLite:', rows);
//         });

//         db.all('SELECT * FROM client_mysql_data', (err, rows) => {
//             if (err) {
//                 console.error('Error fetching data from client_mysql_data in SQLite:', err);
//                 return;
//             }
//             console.log('Client_MySQL Data in SQLite:', rows);
//         });

//         db.all('SELECT * FROM jobs_mysql_data', (err, rows) => {
//             if (err) {
//                 console.error('Error fetching data from jobs_mysql_data in SQLite:', err);
//                 return;
//             }
//             console.log('Jobs_MySQL Data in SQLite:', rows);
//         });
//     });
//     db.close();
// }

// // Main function to fetch data and insert into SQLite
// async function main() {
//     try {
//         const mongoData = await fetchDataFromMongoDB();
//         const { clientRows, jobsRows } = await fetchDataFromMySQL();
        
//         await insertMongoDBDataIntoSQLite(mongoData);
//         await insertClientDataIntoSQLite(clientRows);
//         await insertJobsDataIntoSQLite(jobsRows);

//         fetchAndLogSQLiteData();
//     } catch (error) {
//         console.error('Error:', error);
//     }
// }

// main();

//------------------------------------------------------------------------------------------------------------------------------------------------------------



const sqlite3 = require('sqlite3').verbose();
const { MongoClient, ObjectId } = require('mongodb');
const mysql = require('mysql2/promise');

// MySQL configuration
const mysqlConfig = {
    host: 'demo-coucal-db.cba0oi2ek1d8.ap-south-1.rds.amazonaws.com',
    user: 'ayush',
    password: 'ayush',
    database: 'demo_coucal'
};

// MongoDB configuration
const mongoUrl = 'mongodb://ayush:ayush@demo-coucal-documentdb-cluster.cluster-cba0oi2ek1d8.ap-south-1.docdb.amazonaws.com:27017/?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false';
const mongoDbName = 'demo-coucal';
const mongoCollectionName = 'Resume_Details';

// Function to fetch data from MongoDB
async function fetchDataFromMongoDB() {
    try {
        const client = new MongoClient(mongoUrl, { useUnifiedTopology: true });
        await client.connect();
        console.log('Connected to MongoDB');
        const db = client.db(mongoDbName);
        const collection = db.collection(mongoCollectionName);
        const data = await collection.find({}).toArray();
        await client.close();
        return data;
    } catch (error) {
        console.error('Error fetching data from MongoDB:', error);
        throw error;
    }
}

// Function to fetch data from MySQL
async function fetchDataFromMySQL() {
    try {
        const connection = await mysql.createConnection(mysqlConfig);
        console.log('Connected to MySQL');

        // Fetch data from client_table
        const [clientRows] = await connection.execute('SELECT * FROM client_table');
        
        // Fetch data from jobs_table
        const [jobsRows] = await connection.execute('SELECT * FROM jobs_table');
        await connection.end();

        return { clientRows, jobsRows };
    } catch (error) {
        console.error('Error fetching data from MySQL:', error);
        throw error;
    }
}

// Function to insert MySQL client data into SQLite
async function insertClientDataIntoSQLite(data) {
    try {
        const db = new sqlite3.Database('data.db');
        console.log('Connected to SQLite');

        db.serialize(() => {
            db.run(`CREATE TABLE IF NOT EXISTS client_mysql_data (
                address TEXT,
                client_id INTEGER,
                creator_email_id TEXT,
                creation_date TEXT,
                client_website TEXT,
                client_name TEXT,
                balance REAL,
                job_count TEXT,
                plan TEXT
            )`);

            const stmt = db.prepare(`INSERT INTO client_mysql_data (
                address,
                client_id,
                creator_email_id,
                creation_date,
                client_website,
                client_name,
                balance,
                job_count,
                plan
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);

            data.forEach((row) => {
                stmt.run(
                    row.address || '',
                    row.client_id || 0,
                    row.creator_email_id || '',
                    row.creation_date ? new Date(row.creation_date).toISOString() : '',
                    row.client_website || '',
                    row.client_name || '',
                    row.balance || 0,
                    row.job_count || '',
                    row.plan || ''
                );
            });
            stmt.finalize();
        });

        db.close();
        console.log('Client MySQL data inserted into SQLite');
    } catch (error) {
        console.error('Error inserting client MySQL data into SQLite:', error);
        throw error;
    }
}


// Function to insert Jobs MySQL data into SQLite
async function insertJobsDataIntoSQLite(data) {
    const db = new sqlite3.Database('data.db');

    try {
        await db.run(`CREATE TABLE IF NOT EXISTS jobs_mysql_data (
            job_id INTEGER PRIMARY KEY,
            job_title TEXT,
            address TEXT,
            country TEXT,
            job_type TEXT,
            schedule TEXT,
            number_of_vacancies INTEGER,
            target_hiring_date TEXT,
            skills TEXT,
            deal_breaker_questions TEXT,
            normal_questions TEXT,
            client_id INTEGER,
            creation_date TEXT,
            suspend_job TEXT,
            suspension_date TEXT,
            pause_job TEXT,
            resumes_executed INTEGER,
            job_desc TEXT,
            start_date TEXT,
            qualification_required TEXT,
            experience_required TEXT,
            key_responsibilities TEXT,
            job_category TEXT,
            total_files_uploaded INTEGER,
            job_tag TEXT,
            rankwithlocation TEXT,
            week_range TEXT,
            perday_start_time TEXT,
            perday_end_time TEXT,
            credit_score INTEGER,
            screening_questions TEXT,
            technical_call TEXT,
            screening_call TEXT,
            job_site TEXT,
            job_city TEXT,
            salary_range TEXT,
            hourly_price TEXT,
            remote_options TEXT,
            skip_holidays TEXT,
            job_longitude TEXT,
            job_latitude TEXT,
            job_state TEXT
        )`);

        // Extract field names from the first row of data
        const fields = Object.keys(data[0]);

        // Generate SQL placeholders for values
        const placeholders = fields.map(() => '?').join(', ');

        const stmt = db.prepare(`INSERT OR REPLACE INTO jobs_mysql_data (${fields.join(', ')}) VALUES (${placeholders})`);

        for (const row of data) {
            await stmt.run(
                ...fields.map(field => row[field] || null) // Map each field to its value or null if empty
            );
        }

        stmt.finalize();

        console.log('Jobs MySQL data inserted into SQLite');
    } catch (error) {
        console.error('Error inserting jobs MySQL data into SQLite:', error);
        throw error;
    } finally {
        db.close();
    }
}



// Function to insert MongoDB data into SQLite
async function insertMongoDBDataIntoSQLite(data) {
    try {
        const db = new sqlite3.Database('data.db');
        console.log('Connected to SQLite');

        // Delete the existing table
        await new Promise((resolve, reject) => {
            db.run(`DROP TABLE IF EXISTS mongodb_data`, (err) => {
                if (err) {
                    console.error('Error deleting mongodb_data table:', err);
                    reject(err);
                } else {
                    console.log('mongodb_data table deleted');
                    resolve();
                }
            });
        });

        // Create the table
        await new Promise((resolve, reject) => {
            db.run(`CREATE TABLE IF NOT EXISTS mongodb_data (
                _id TEXT PRIMARY KEY,
                Name TEXT,
                Current_Location TEXT,
                Phone_Number TEXT,
                Email_ID TEXT,
                Profile_Link TEXT,
                Work_Experience REAL,
                Skills TEXT,
                Qualification TEXT,
                Projects TEXT,
                client_id TEXT,
                job_id TEXT,
                resume_id TEXT,
                nearby TEXT,
                screening_call_date TEXT,
                screening_call_status TEXT,
                screening_call_day TEXT,
                screening_call_start_time TEXT,
                screening_call_end_time TEXT,
                ranklocation TEXT,
                candidate_score INTEGER,
                matching_skills TEXT,
                matching_work_experience TEXT
            )`, (err) => {
                if (err) {
                    console.error('Error creating mongodb_data table:', err);
                    reject(err);
                } else {
                    console.log('mongodb_data table created');
                    resolve();
                }
            });
        });

        // Prepare the insert statement
        const stmt = db.prepare(`INSERT INTO mongodb_data (
            _id,
            Name,
            Current_Location,
            Phone_Number,
            Email_ID,
            Profile_Link,
            Work_Experience,
            Skills,
            Qualification,
            Projects,
            client_id,
            job_id,
            resume_id,
            nearby,
            screening_call_date,
            screening_call_status,
            screening_call_day,
            screening_call_start_time,
            screening_call_end_time,
            ranklocation,
            candidate_score,
            matching_skills,
            matching_work_experience
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

        // Insert data into the table
        data.forEach((doc) => {
            const idString = doc._id instanceof ObjectId ? doc._id.toString() : doc._id;
            stmt.run(
                idString,  // Ensure _id is converted to string
                doc.Name || '',
                Array.isArray(doc.Current_Location) ? doc.Current_Location.join(', ') : (doc.Current_Location || ''),
                Array.isArray(doc.Phone_Number) ? doc.Phone_Number.join(', ') : (doc.Phone_Number || ''),
                Array.isArray(doc.Email_ID) ? doc.Email_ID.join(', ') : (doc.Email_ID || ''),
                doc.Profile_Link || '',
                doc.Work_Experience || 0,
                Array.isArray(doc.Skills) ? doc.Skills.join(', ') : (doc.Skills || ''),
                Array.isArray(doc.Qualification) ? doc.Qualification.join(', ') : (doc.Qualification || ''),
                Array.isArray(doc.Projects) ? doc.Projects.join(', ') : (doc.Projects || ''),
                doc.client_id || '',
                doc.job_id || '',
                doc.resume_id || '',
                doc.nearby.toString(),
                doc.screening_call_date || '',
                doc.screening_call_status || '',
                doc.screening_call_day || '',
                doc.screening_call_start_time || '',
                doc.screening_call_end_time || '',
                doc.ranklocation || '',
                doc.candidate_score || 0,
                doc.matching_skills || '',
                doc.matching_work_experience || ''
            );
        });

        // Finalize the statement
        stmt.finalize();

        console.log('Data inserted into mongodb_data table');

        // Close the database connection
        db.close();
    } catch (error) {
        console.error('Error inserting MongoDB data into SQLite:', error);
        throw error;
    }
}
// Function to fetch and log SQLite data
function fetchAndLogSQLiteData() {
    const db = new sqlite3.Database('data.db');
    db.serialize(() => {
        db.all('SELECT * FROM mongodb_data', (err, rows) => {
            if (err) {
                console.error('Error fetching data from mongodb_data in SQLite:', err);
                return;
            }
            console.log('MongoDB Data in SQLite:', rows);
        });

        db.all('SELECT * FROM client_mysql_data', (err, rows) => {
            if (err) {
                console.error('Error fetching data from client_mysql_data in SQLite:', err);
                return;
            }
            console.log('Client_MySQL Data in SQLite:', rows);
        });

        db.all('SELECT * FROM jobs_mysql_data', (err, rows) => {
            if (err) {
                console.error('Error fetching data from jobs_mysql_data in SQLite:', err);
                return;
            }
            console.log('Jobs_MySQL Data in SQLite:', rows);
        });
    });
    db.close();
}
// Main function to fetch data and insert into SQLite
async function main() {
    try {
        const mongoData = await fetchDataFromMongoDB();
        const { clientRows, jobsRows } = await fetchDataFromMySQL();
        
        await insertMongoDBDataIntoSQLite(mongoData);
        await insertClientDataIntoSQLite(clientRows);
        await insertJobsDataIntoSQLite(jobsRows);

        fetchAndLogSQLiteData();
    } catch (error) {
        console.error('Error:', error);
    }
}

main();